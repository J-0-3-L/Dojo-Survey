package com.joel.encuesta;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EncuestaApplicationTests {

	@Test
	void contextLoads() {
	}

}
